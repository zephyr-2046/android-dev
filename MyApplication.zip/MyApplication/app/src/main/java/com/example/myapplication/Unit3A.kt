package com.example.myapplication

class Unit3A {

    fun calculateSum( a : Int, b: Int) : Int {
        return a*2 + b
    }
}